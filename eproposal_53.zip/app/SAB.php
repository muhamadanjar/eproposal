<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SAB extends Model
{
    protected $table = 'sab';
    protected $primaryKey = 'id';
}
