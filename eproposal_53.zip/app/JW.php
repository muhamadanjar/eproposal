<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\JW;
class JW extends Model{
    protected $table = 'jenis_wilayah';
    protected $primaryKey = 'id';


   
}
