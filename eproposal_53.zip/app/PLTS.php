<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PLTS extends Model
{
    protected $table = 'plts';
    protected $primaryKey = 'id';
}
