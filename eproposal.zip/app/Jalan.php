<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jalan extends Model
{
    protected $table = 'jalansirip';
    protected $primaryKey = 'id';
}
