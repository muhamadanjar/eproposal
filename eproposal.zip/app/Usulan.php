<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usulan extends Model{
    protected $table = 'usulan';
    protected $primaryKey = 'id';

    public function jalan(){
        return $this->hasMany('App\Jalan');
    }

    public function sab(){
        return $this->hasMany('App\SAB');
    }

    public function plts(){
        return $this->hasMany('App\PLTS');
    }
}
